package colculaterapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ColculaterApp extends JFrame implements ActionListener {

    private JTextField display;
    private boolean isFinished = false;

    public ColculaterApp() {
        setTitle("Simple Calculator");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(30, 30, 30));

        display = new JTextField("");
        display.setFont(new Font("Monospaced", Font.BOLD, 32));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        display.setBackground(Color.BLACK);
        display.setForeground(Color.CYAN);
        display.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 10));
        add(display, BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridLayout(0, 4, 10, 10));
        panel.setBackground(new Color(30, 30, 30));

        String[] buttons = {
                "C", "CE", "DEL", "/",
                "7", "8", "9", "*",
                "4", "5", "6", "-",
                "1", "2", "3", "+",
                "(", "0", ")", ".",
                "(-)", "="
        };

        for (String text : buttons) {
            JButton btn = new JButton(text);
            btn.setFont(new Font("Arial", Font.BOLD, 18));
            btn.setFocusPainted(false);
            btn.addActionListener(this);
            styleButton(btn, text);
            panel.add(btn);
        }

        add(panel, BorderLayout.CENTER);
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        setLocationRelativeTo(null);
    }

    private void styleButton(JButton btn, String text) {
        if ("/*-+".contains(text) || text.equals("(-)")) {
            btn.setBackground(new Color(33, 150, 243));
            btn.setForeground(Color.WHITE);
        } else if (text.equals("=")) {
            btn.setBackground(new Color(76, 175, 80));
            btn.setForeground(Color.WHITE);
        } else if (text.equals("C") || text.equals("CE") || text.equals("DEL")) {
            btn.setBackground(new Color(244, 67, 54));
            btn.setForeground(Color.WHITE);
        } else {
            btn.setBackground(Color.WHITE);
            btn.setForeground(Color.BLACK);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();

        if (display.getText().equals("Invalid")) {
            display.setText("");
        }

        if (cmd.equals("=")) {
            solveExpression();
            isFinished = true;

        } else if (cmd.equals("C") || cmd.equals("CE")) {
            display.setText("");

        } else if (cmd.equals("DEL")) {
            String str = display.getText();
            if (str.length() > 0) {
                display.setText(str.substring(0, str.length() - 1));
            }

        } else if (cmd.equals("(-)")) {
            display.setText(display.getText() + "(-1)*");

        } else {
            String text = display.getText();

            if ("+-*/".contains(cmd)) {
                if (text.isEmpty() || "+-*/".contains("" + text.charAt(text.length() - 1))) {
                    return;
                }
            }

            if (isFinished && "0123456789(".contains(cmd)) {
                display.setText("");
            }

            display.setText(display.getText() + cmd);
            isFinished = false;
        }
    }

    private void solveExpression() {
        String expression = display.getText();
        if (expression.isEmpty()) return;

        try {
            double result = eval(expression);

            if (Double.isInfinite(result) || Double.isNaN(result)) {
                display.setText("Invalid");
                return;
            }

            if (result == (long) result) {
                display.setText(String.format("%d", (long) result));
            } else {
                display.setText(String.valueOf(result));
            }

        } catch (Exception ex) {
            display.setText("Invalid");
        }
    }

    public static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor();
                    else if (eat('/')) {
                        double divisor = parseFactor();

                        if (divisor == 0) {
                            throw new ArithmeticException("Division by zero");
                        }

                        x /= divisor;
                    } else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('-')) return -parseFactor();

                double x;
                int startPos = this.pos;

                if (eat('(')) {
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                return x;
            }
        }.parse();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ColculaterApp().setVisible(true));
    }
}

